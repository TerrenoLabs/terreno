---
name: team-poster
description: Make team posters in the shared house look.
---

# Team poster

Use bold flat colors. Reference: refs/logo.png
